import os
from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)
BASE = os.path.dirname(__file__)
MODEL_PATH = os.path.join(BASE, "model.pkl")

if not os.path.exists(MODEL_PATH):
    from train import train_and_save
    train_and_save(MODEL_PATH)

model = joblib.load(MODEL_PATH)
FEATURE_NAMES = ["sepal_length", "sepal_width", "petal_length", "petal_width"]

@app.route("/")
def home():
    return "Small model API is running"

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "no JSON body received"}), 400

    try:
        if "instances" in data:
            X = data["instances"]
        elif "features" in data:
            X = [[data["features"].get(f) for f in FEATURE_NAMES]]
        elif isinstance(data, list):
            X = data
        else:
            X = [[data.get(f) for f in FEATURE_NAMES]]

        preds = model.predict(X)
        return jsonify({"predictions": preds.tolist()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
