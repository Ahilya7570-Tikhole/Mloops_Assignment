from app import app

def test_predict_single():
    client = app.test_client()
    payload = {"features": {"sepal_length":5.1,"sepal_width":3.5,"petal_length":1.4,"petal_width":0.2}}
    r = client.post("/predict", json=payload)
    assert r.status_code == 200
    data = r.get_json()
    assert "predictions" in data
    assert isinstance(data["predictions"], list)
