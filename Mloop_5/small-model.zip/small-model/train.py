import os
import joblib
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier

def train_and_save(path="model.pkl"):
    iris = load_iris()
    X, y = iris.data, iris.target
    clf = RandomForestClassifier(n_estimators=10, random_state=42)
    clf.fit(X, y)
    joblib.dump(clf, path)
    print(f"Saved model to {path}")

if __name__ == "__main__":
    out = os.path.join(os.path.dirname(__file__), "model.pkl")
    train_and_save(out)
